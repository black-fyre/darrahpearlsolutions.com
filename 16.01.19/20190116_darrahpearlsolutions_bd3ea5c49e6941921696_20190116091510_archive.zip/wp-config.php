<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress_sites');

/** MySQL database username */
define('DB_USER', 'wordpress_user');

/** MySQL database password */
define('DB_PASSWORD', 'OLOy^de33!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')STeP%Xyp<@! 6|69Sde5,d7hPD@cn?~Q|U(2Al)5SL9/}y[}KbX0}}h-y^tOGu2');
define('SECURE_AUTH_KEY',  '#kr{x~|N+J9F<^5MyK*a6f J-Gx;YlHwKECp`7uQxL@! Y%#2~<T,xn:TuD~e^Z|');
define('LOGGED_IN_KEY',    '7dq~k9O][)_jVv;Wxm3lUFH8S,13/7Wwr;TP(!a/?{dWkp+5i`dR@ktu?MC>ouul');
define('NONCE_KEY',        'G=hw$l<$,C{ f-EX[c}5]e-4(}Bks#5CL7t-%]1}M#DwjvjFpP~n4na_,6hiST6+');
define('AUTH_SALT',        's:o1Qk#1q8pEz.R&[y~wGY(uAv$i@OuNvF}9t{cM?BHt3`OshhK,<?kj!#83a3H5');
define('SECURE_AUTH_SALT', 'n4Ml8kDmZ-UYseyTj6koUVfCJkScUIDX:fn1|al]zP/PJ_+vq}6};jp6|hxLALm3');
define('LOGGED_IN_SALT',   'Ss?`oD9#FersEbi{I)tu^+$i973PgX)I2p_U(9~(v~f7XprO9gJWR<>|4?)Mc@`5');
define('NONCE_SALT',       'dq07n1Eqku;Y{a_AxyiVYsBJ|q=K*tYc]p]/6o51@-_?z3eqpo8bO(JJ/Z#{XZ7Z');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'tee75_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
